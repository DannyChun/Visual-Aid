#!/usr/bin/env bash

export CUDA_VERSION="11.7"
export CUDA_VERSION_DASHED="${CUDA_VERSION//./-}"
export CUDNN_VERSION="8.4.1"
export CUDNN_VERSION_DASHED="${CUDNN_VERSION//./-}"
